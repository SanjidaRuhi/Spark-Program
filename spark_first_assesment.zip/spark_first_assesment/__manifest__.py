# -*- coding: utf-8 -*-
{
    'name': "spark_first_assesment",

    'summary': """
        this is my first spark assesment module """,

    'description': """
        all details about the app will be here.....
    """,
    'sequence' : '-100',

    'author': "sanjida",

    'website': "",

    'category': 'Education',

    'version': '1.0',

    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        'views/assesment_views.xml',
        'views/assesment_menu.xml'
    ],

}