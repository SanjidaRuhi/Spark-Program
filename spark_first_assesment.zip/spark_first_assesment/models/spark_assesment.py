from odoo import fields, models

class Spark(models.Model):
    _name = 'spark.assesment'
    _rec_name = 'name'
    _description = 'this is first spark assesment model'

    name = fields.Char(string="Name", required=True)
    date = fields.Date(string="Date", required=True)
    email = fields.Char(string="Email", required=True)
    description = fields.Text(string="Description", required=True)
    marks = fields.Float(string="Marks", required=True)
    total_participant = fields.Integer(string="Total Participant", required=True)
    program_start_time = fields.Datetime(string="Program Start Time", required=True)
    program_end_time = fields.Datetime(string="Program End Time", required=True)



